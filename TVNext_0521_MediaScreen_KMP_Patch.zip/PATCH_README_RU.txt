TVNext 0.5.21 — патч KMP MediaScreen для агентского рабочего дерева

Патч содержит только три пути относительно КОРНЯ проекта (где settings.gradle.kts):
features/media/src/commonMain/kotlin/com/tvnext/app/feature/media/ui/MediaScreen.kt
features/media/src/androidMain/kotlin/com/tvnext/app/feature/media/ui/MediaScreen.android.kt
features/media/src/desktopMain/kotlin/com/tvnext/app/feature/media/ui/MediaScreen.desktop.kt

Сначала сделайте резервную копию исходников. Замените первый файл и добавьте два новых с сохранением структуры папок. Шесть обычных исправлений из вашего отчёта остаются в текущем рабочем дереве и не перезаписываются этим маленьким патчем.

Идея: expect/actual MediaScreen, общая сигнатура в commonMain, Android -> AndroidMediaScreen, Desktop -> старый Desktop-код.

Не меняйте AGP/Kotlin/Gradle ради этого патча. Не удаляйте externalNativeBuild и native-библиотеки. Не перезаписывайте оригинальный релиз TVNext 0.5.21.

Проверка: :apps:android:assembleRelease --stacktrace (после сохранения текущих настроек подписи).
Если появится следующая ошибка — приложите первые строки ERROR и весь Caused by.

Полноценная компиляция в нашей текущей среде не проводилась.
