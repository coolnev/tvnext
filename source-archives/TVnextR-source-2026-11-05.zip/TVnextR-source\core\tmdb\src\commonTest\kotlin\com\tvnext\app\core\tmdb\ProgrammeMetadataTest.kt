package com.tvnext.app.core.tmdb

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull
import kotlin.test.assertTrue

class ProgrammeMetadataTest {
    @Test fun russianTitleAndYearAreMatched() {
        assertTrue(similarProgrammeTitle("Хитровка. Знак четырех", "Хитровка: Знак четырёх (2023)"))
        assertTrue(similarProgrammeTitle("Ёжик в тумане (1975)", "Ежик в тумане"))
    }

    @Test fun episodeMarkersDoNotBlockSeriesDescriptions() {
        assertTrue(similarProgrammeTitle("Тайны следствия", "Тайны следствия. Сезон 5, серия 3"))
        assertTrue(similarProgrammeTitle("Побег", "Побег S02E04"))
        assertTrue(!similarProgrammeTitle("Побег", "Побег 2"))
    }

    @Test fun unrelatedMoviesAreRejected() {
        assertTrue(!similarProgrammeTitle("Хитровка", "Хитровка. Знак четырех"))
        assertTrue(!similarProgrammeTitle("Хитровка 2", "Хитровка"))
        assertNull(parseKinopoiskSearch("""{"docs":[{"name":"Другой фильм","description":"Чужое описание"}]}""", "Хитровка"))
    }

    @Test fun kinopoiskFixturePrefersExactNameAndHttpsImage() {
        val json = """{"docs":[
          {"name":"Другой фильм","description":"Неверно"},
          {"name":"Хитровка. Знак четырех (2023)","description":"Описание",
           "poster":{"url":"https://example.org/poster.jpg"},
           "backdrop":{"url":"http://example.org/unsafe.jpg"}}
        ]}"""
        val result = parseKinopoiskSearch(json, "Хитровка. Знак четырех")
        assertEquals("Описание", result?.overview)
        assertEquals("https://example.org/poster.jpg", result?.posterUrl)
        assertNull(result?.frameUrl)
    }
    @Test fun kinopoiskSearchPosterWithoutDescriptionCanBeEnrichedById() {
        val search = """{"docs":[{"id":535341,"name":"Хитровка. Знак четырех", "poster":{"url":"https://example.org/p.jpg"},"description":null}]}"""
        assertEquals(535341, kinopoiskMatchedId(search, "Хитровка. Знак четырех"))
        val hit = parseKinopoiskSearch(search, "Хитровка. Знак четырех")
        assertNull(hit?.overview)
        assertEquals("https://example.org/p.jpg", hit?.posterUrl)
        val detail = parseKinopoiskDetails("""{"description":"Описание из полной карточки", "poster":{"url":"https://example.org/p.jpg"}}""")
        assertEquals("Описание из полной карточки", detail.overview)
    }

    @Test fun kinopoiskFullCardUsesShortDescriptionIfFullIsAbsent() {
        val full = parseKinopoiskDetails("""{"description":null,"shortDescription":"Краткий сюжет", "backdrop":{"url":"https://example.org/f.jpg"}}""")
        assertEquals("Краткий сюжет", full.overview)
        assertEquals("https://example.org/f.jpg", full.frameUrl)
    }

}
